// initiate nodeJS
// const fs = require("fs");

//nodeJS - write on txt file
// fs.writeFile("message.txt", "Hello NodeJS!!!", (err) => {
//   if (err) throw err;
//   console.log("The file has been saved!");
// });


//nodeJS - return what is in txt file
// fs.readFile("./message.txt","utf8", (err, data) => {
//   if (err) throw err;
//   console.log(data);
// });

//NPM - after installing sillyname module
// var generateName = require('sillyname');
// var sillyName = generateName();
// console.log('My name is '+sillyName);
 //or 
 //using external node modules
import superheroes from "superheroes";
const superh= superheroes[Math.floor(Math.random()*superheroes.length)];
console.log("My superheroe name is " +superh);