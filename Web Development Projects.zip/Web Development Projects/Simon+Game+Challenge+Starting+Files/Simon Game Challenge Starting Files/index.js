var level=0;

$(document).keypress(function(){ //change color once button is pressed
    
  $("#level-title").html("Level 1");

    nextSequence();  
    
});

var buttonColours = ["red", "blue", "green", "yellow"];
var userClickedPattern=[];

var gamePattern = [];


$(".btn").click(function() {
  var userChosenColour =this.id;
  userClickedPattern.push(userChosenColour);
  console.log(userClickedPattern);

  

  var playSound = new Audio('sounds/'+userChosenColour+'.mp3');
  playSound.play();

  animatePress(userChosenColour);
});

function nextSequence() {

  var randomNumber = Math.floor(Math.random() * 4);
  var randomChosenColour = buttonColours[randomNumber];
  gamePattern.push(randomChosenColour);

  $("#"+randomChosenColour).fadeIn(100).fadeOut(100).fadeIn(100);
  var playColor = new Audio('sounds/'+randomChosenColour+'.mp3');
  playColor.play();

  level++;
  $("#level-title").html("Level "+level);

};

function animatePress(currentColour){
  $('#'+currentColour).addClass("pressed");
  setTimeout(function(){
      $('#'+currentColour).removeClass("pressed");
  },100);};

function checkAnswer(currentLevel){

};


$("button").click(function(event){

    console.log($("button").attr("class"));
    makeSound(event.key);
  
    buttonAnimation(event.key);
  
  });

function makeSound(color) {

    switch (color) {
      case "blue":
        var blue = new Audio("sounds/blue.mp3");
        blue.play();
        break;
  
      case "green":
        var tom2 = new Audio("sounds/green.mp3");
        tom2.play();
        break;
  
      case "red":
        var tom3 = new Audio('sounds/red.mp3');
        tom3.play();
        break;
  
      case "yellow":
        var tom4 = new Audio('sounds/yellow.mp3');
        tom4.play();

      case "wrong":
        var kick = new Audio('sounds/wrong.mp3');
        kick.play();
        break;
      
      
        default: console.log(key);
      
        }
      }
      