document.querySelector("button").style.backgroundColor = "yellow";
document.querySelector("button").classList.add("invisible");
document.querySelector("h1").classList.add("huge");