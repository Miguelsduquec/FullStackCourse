
$(document).ready(function()
{
// $("h1").css("color","red");
// $("h1").css("background-color","green");

});
//CLASSES
$("h1").addClass("big-title margin-50") //add 2 classes
$("h1").removeClass("big-title") //remove 1 class

$("button").text("CLICK ME TWO TIMES") //change text
$("button").html("<em>CLICK ME TWO TIMES</em>") //change htlm text (and put it italic)

//ATTRIBUTES
console.log($("img").attr("src")); // get the value of an attribute
$("a").attr("href", "http://www.bing.com"); // set the value of an attribute

console.log($("h1").attr("class")); // return all classes on element h1

//ADD EVENT LISTENERS

$("button").click(function(){ //change color once button is pressed
    $("h1").css("color","red");
});

$("input").keypress(function(event){ //returns into console text typed in input box
console.log(event.key);
});

$(document).keypress(function(event){ //returns into console text typed in all website. Can use "body" too
    console.log(event.key);
    });
    
$(document).keypress(function(event){ //returns into h2 letter typed in all website. Can use "body" too
    $("h2").html(event.key);
    });

$("h1").on("mouseover", function(){
    $( this ).fadeOut( 100 );
    $( this ).fadeIn( 500 ); // or use only fadetoggle()
})
