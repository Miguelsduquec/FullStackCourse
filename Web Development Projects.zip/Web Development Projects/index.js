function fibonacciGenerator (n) {
    //Do NOT change any of the code above 👆
        
        //Write your code here:
        
        for(var i=0;i<n;i++)
        {
            var seq=[];
            
            if (i==0){seq.push(0)};
            if (i==1){seq.push(1)};
            
            if(i>1){
                var numElem=seq.lenght;
                var nextElem=seq[numElem]+seq[numElem-1]}
                seq.push(nextElem);
                    }
            
            console.log(seq);
            
            
        }
    
    fibonacciGenerator (2);




//Function calling a function
//Use it on console
//Use debuger before code to go step by step


function add(num1,num2){
    return num1+num2;
}

function mul(num1,num2){
    return num1*num2;
}

function calc(num1,num2,operator){
    return operator(num1,num2);
}

debugger;
calc(2,3,mul);